The file RUN.PY has several threads whee each file is called sequentially.

It is enough to run RUN.py which inturn obtains data from the robot and also localizes it.
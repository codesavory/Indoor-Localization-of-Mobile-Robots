var searchData=
[
  ['setarefvoltage',['setARefVoltage',['../class_analog_distance_sensor.html#a7e8c18ea2a45d5b683b6cb04139396c8',1,'AnalogDistanceSensor']]],
  ['setaveraging',['setAveraging',['../class_distance_sensor.html#a77ec007235ec2e52d0e74507ec6afbc6',1,'DistanceSensor']]]
];

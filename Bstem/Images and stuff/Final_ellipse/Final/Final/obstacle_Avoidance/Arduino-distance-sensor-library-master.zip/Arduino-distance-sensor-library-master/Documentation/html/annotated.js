var annotated =
[
    [ "AnalogDistanceSensor", "class_analog_distance_sensor.html", "class_analog_distance_sensor" ],
    [ "DistanceGP2Y0A21YK", "class_distance_g_p2_y0_a21_y_k.html", "class_distance_g_p2_y0_a21_y_k" ],
    [ "DistanceGP2Y0A41SK", "class_distance_g_p2_y0_a41_s_k.html", "class_distance_g_p2_y0_a41_s_k" ],
    [ "DistanceSensor", "class_distance_sensor.html", "class_distance_sensor" ],
    [ "DistanceSRF04", "class_distance_s_r_f04.html", "class_distance_s_r_f04" ],
    [ "UltrasonicDistanceSensor", "class_ultrasonic_distance_sensor.html", "class_ultrasonic_distance_sensor" ]
];
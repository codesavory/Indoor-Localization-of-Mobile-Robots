var class_distance_sensor =
[
    [ "isCloser", "class_distance_sensor.html#aaeb8f74df2282153123c30e07c775724", null ],
    [ "isFarther", "class_distance_sensor.html#a4135f6f4c351c5f0d001dbedab118dc4", null ],
    [ "setAveraging", "class_distance_sensor.html#a77ec007235ec2e52d0e74507ec6afbc6", null ],
    [ "_average", "class_distance_sensor.html#af58f6a161dff2f02fd65b26eed200460", null ]
];